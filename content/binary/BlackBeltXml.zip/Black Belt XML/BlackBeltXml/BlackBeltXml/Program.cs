using System;
using System.Xml;
using System.Collections.Generic;
using System.Text;

namespace BlackBeltXml
{
    class Program
    {
        static void Main(string[] args)
        {
            XmlDocument booksDoc = new XmlDocument();

            booksDoc.Load("books.xml");

            Console.WriteLine(booksDoc.SelectSingleNode("/*[local-name()='Books']/*[local-name()='Book']/*[local-name()='Title']").InnerText);
            Console.ReadLine();
        }
    }
}
