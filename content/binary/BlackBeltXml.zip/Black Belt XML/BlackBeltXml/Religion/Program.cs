using System;
using System.Xml;
using System.Collections.Generic;
using System.Text;

namespace Religion
{

    class Program
    {




        static void Main(string[] args)
        {
            try {
                CleanClock();
                Console.WriteLine("Starting XmlDocument : {0}", DateTime.Now);
                for (int docIndex = 0; docIndex < 100; docIndex++)
                {
                    DocumentSearch();
                }
                Console.WriteLine("Ending XmlDocument : {0}", DateTime.Now);

                Console.WriteLine();
                Console.WriteLine();

                CleanClock();
                Console.WriteLine("Starting XmlReader : {0}", DateTime.Now);
                for (int docIndex = 0; docIndex < 100; docIndex++)
                {
                    ReaderFactory();
                }
                Console.WriteLine("Ending XmlReader : {0}", DateTime.Now);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
            finally
            {
                Console.ReadLine();
            }
        }

        public static void CleanClock()
        {
            while ((DateTime.Now.Second % 10) != 0)
            {
                System.Threading.Thread.Sleep(250);
            }
        }

        public static void DoNotKill()
        {
            XmlDocument xDoc = new XmlDocument();

            xDoc.Load("ot.xml");
            XmlNode oVerse = xDoc.SelectSingleNode(
                "//chapter[ancestor::book/bktshort='Exodus' and chtitle='Chapter 20']/v[13]");

            Console.WriteLine(oVerse.InnerText.Trim());

            xDoc.Load("quran.xml");
            XmlNode qVerse = xDoc.SelectSingleNode(
                "//sura[substring(bktshort,1,2)='17']/v[33]");

            Console.WriteLine(qVerse.InnerText.Trim());
        }

        public static void DocumentSearch()
        {
            XmlDocument xDoc = new XmlDocument();

            xDoc.Load("ot.xml");
            XmlNode oVerse = xDoc.SelectSingleNode(
                "//chapter[ancestor::book/bktshort='Exodus' and chtitle='Chapter 20']/v[13]");

            Console.WriteLine(oVerse.InnerText.Trim());
        }

        public static void ReaderFactory()
        {
            XmlReaderSettings rs = new XmlReaderSettings();
            rs.CloseInput = true;
            rs.IgnoreComments = true;
            rs.IgnoreProcessingInstructions = true;
            rs.IgnoreWhitespace = true;
            rs.ProhibitDtd = true;
            rs.ValidationType = ValidationType.None;

            using(XmlReader xReader = XmlReader.Create("ot.xml",rs))
            {
                bool bookFound = false;
                bool chapFound = false;
                int verseCount = 0;

                while (xReader.Read())
                {
                    if (xReader.NodeType == XmlNodeType.Element && xReader.Name == "bktshort")
                    {
                        xReader.Read();
                        if (xReader.Value == "Exodus")
                            bookFound = true;
                    }

                    if (bookFound && xReader.NodeType == XmlNodeType.Element && xReader.Name == "chtitle")
                    {
                        xReader.Read();
                        if (xReader.Value == "Chapter 20")
                            chapFound = true;
                    }

                    if (bookFound && chapFound && xReader.NodeType == XmlNodeType.Element && xReader.Name == "v")
                        verseCount++;

                    if (bookFound && chapFound && xReader.NodeType == XmlNodeType.Element && verseCount == 13)
                    {
                        xReader.Read();
                        Console.WriteLine(xReader.Value.Trim());
                        break;
                    }
                }
            }
        }
    }
}
